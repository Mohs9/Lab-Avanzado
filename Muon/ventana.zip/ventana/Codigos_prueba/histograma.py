import numpy as np
import csv
import pylab as py
import matplotlib.pyplot as plt
from scipy.optimize import curve_fit
import pandas as pd


data = pd.read_csv('tiempos.csv',  usecols= ['1892.5'])

counts, bins, bars = plt.hist(data,40)

xdata= np.array(bins)
xdata = np.delete(xdata, xdata.shape[0] - 1)

def fit_function(x,A, B):
    return (A*np.exp(-x*B))


print(counts)
print(xdata)

dict = {'conteos':counts,'tiempos':xdata} 
df = pd.DataFrame(dict) 
df.to_csv('test.csv')


popt, pcov = curve_fit(fit_function, xdata, counts, p0=(1000, 2200))
print(popt)

plt.plot(xdata,counts)
xx = np.linspace(1000, 6000, 10000)
yy = fit_function(xx, *popt)
plt.plot(xx, yy)

plt.show()

'''
plt.hist(data, 50)



plt.show()
'''