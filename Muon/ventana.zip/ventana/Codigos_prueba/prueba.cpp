#include <iostream>
#include <string>
#include <vector>
#include <cstring>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>

#include "TTree.h"
#include "TFile.h"
#include "TCanvas.h"
#include "TH1D.h"
#include "TRandom3.h"

using namespace std;
fstream Myfile;

/* Esta función lee un árbol de un archivo y un histograma
 * para cada rama del árbol */
void ReadTree(const char * NombreDelArchivo)
{
    /* Primero se abre el archivo para lectura */
    TFile *oFile = new TFile(NombreDelArchivo);
    
    
    double time = 0;
    double count=0;
    
    if(!oFile)
    {
        std::cout<<"No fue posible abrir el archivo "<< NombreDelArchivo << std::endl;
        return;
    }

    /* Se crea un puntero de árbol para cargar los datos 
     * del archivo */
    TTree *oTree;

    /* Se busca el árbol en el archivo. Nótese que se debe
     * saber el nombre del árbol que se desea cargar. */
    oTree = (TTree*)oFile->Get("mytree");

    /* Para cargar los datos del árbol, se debe conocer la
     * estructura con que este fue creado, ya que se deben 
     * extraer los datos de la misma forma.  Se crean un 
     * par de variables Double_t donde se colocarán los datos .*/


    /* Se asocian las direcciones de estas variables con las
     * ramas. */
    oTree->SetBranchAddress("Var_a_Branch",&count);
    oTree->SetBranchAddress("Var_b_Branch",&time);
    
   
    //oTree->SetBranchAddress("b1",&conteos);

    /* Se obtiene el número de entradas */
    Long_t Entradas = (Long_t)oTree->GetEntries();

    fstream ReadFile("graph.csv", ios::in);
    if(!ReadFile){
        fstream CreateFile("graph.csv", ios::out);
    }
    /* Se obtienen los datos */
    Myfile.open("graph.csv",ios::app);
    for(Long_t i = 0; i<Entradas; i++)
    {
        oTree->GetEntry(i);
        Myfile<<time<< ","<<count<<"\n";
    }
    Myfile.close();
    oFile->Close();

}