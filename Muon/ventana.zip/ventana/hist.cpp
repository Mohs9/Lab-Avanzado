#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <iterator>



#include "TROOT.h"
#include "TCanvas.h"
#include "TProfile.h"
#include "TF1.h"
#include "TFile.h"
#include "TH1F.h"
#include "TMultiGraph.h"
#include "TRandom.h"
#include "TGraphErrors.h"
#include "TMath.h"
#include "TTree.h"

using namespace std;
fstream Myfile;


using std::vector;

/* Este programa toma como argumento el nombre del archivo .csv donde se
 * encuentran los datos de los tiempos */

void ReadCSV(const char* FileName){
    //Se inicializan variables 

    std::ifstream CVSFile(FileName); // Se creará otro archivo csv
    std::string line; 
    size_t pos = 0;
    bool NumericValue;
    double time=0;
    double count=0;
    double bins=0;

   


//Se crea un histograma
TH1F* h1 = new TH1F("h1", "Decaimiento del muon",40, 0.5, 40.0);
/*
TFile *af = new TFile("test.root","recreate");
TTree* mytree = new TTree("mytree","Prueba");
TBranch *b1 = mytree->Branch("Var_a_Branch",&count,"count/D");
TBranch *b2 = mytree->Branch("Var_b_Branch",&bins,"bins/D");
*/

// se leen las lineas del archivo csv que recibe como entrada
while(std::getline( CVSFile, line )){

    NumericValue = true;
    if((pos = line.find(",")) != std::string::npos) {
        time= std::stoi(line.substr(0, pos)); //Se almacena en la variable tiempo
        time *=0.001;//Se convierten los nanosegundos a microsegundos.
        line.erase(0, pos + 1);
    }
    
    //se llena el histograma
    if(NumericValue) h1->Fill(time);

}
    //Se crea un nuevo archivo donde se almacenan los resultados del histograma.
    fstream ReadFile("graph.csv", ios::in);
    if(!ReadFile){
        fstream CreateFile("graph.csv", ios::out);
    }

    //Se abre el archivo.
    Myfile.open("graph.csv",ios::app);
    
    for(int i=0; i<=40; i++){
        bins=h1->GetBinCenter(i+2);//centro de cada bin del histograma
        count= h1->GetBinContent(i+2);// conteos por cada bin
        float yerror=0; 
        yerror=h1->GetBinError(i+2);//error
        Myfile<<bins<< ","<<count<<","<<yerror<<"\n";
        //mytree->Fill();
    }
    //se cierra el archivo.
    Myfile.close();
    
//Pasos para dibujar el histograma
TCanvas *c1= new TCanvas();
h1->GetXaxis()->SetTitle("Tiempo");
h1->GetYaxis()->SetTitle("Conteos");

h1 ->Draw();


gStyle->SetOptFit(1);
/*Para hacer el fit se utiliza la función dada por las funciones que ya viene en ROOT
*"expo(1)=e^{[1]+[2]x}" y "pol0=[0]".    
*/
TF1 *lFunc = new TF1("exp","pol0+expo(1)",0.5,40);
lFunc->SetParameter(500,2.2);
//El parametro C es [0], el parametro A e^{[1]}, el parametro B es [2]
lFunc->SetParNames("C","A", "B");
h1->Fit(lFunc,"R");



     
}

