#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <sstream>
#include <iterator>



#include "TROOT.h"
#include "TCanvas.h"
#include "TProfile.h"
#include "TF1.h"
#include "TFile.h"
#include "TH1F.h"
#include "TMultiGraph.h"
#include "TRandom.h"
#include "TGraphErrors.h"
#include "TMath.h"
#include "TTree.h"

using namespace std;
fstream Myfile;


using std::vector;

/*
Double_t fitf(Double_t *x, Double_t *par){
   Double_t arg = 0;
   arg = (x[0] - par[1])/par[2];
   Double_t fitval = par[0]*TMath::Exp(-arg/par[1])+par[2];
   return fitval;
}
*/



 void ReadCSV(const char* FileName){

    std::ifstream CVSFile(FileName);
    std::string line;
    vector<double> numbers;
    size_t pos = 0;
    bool NumericValue;
    double time=0;
    double count=0;
    double bins=0;
    int lineNumber = 0;
    double cont=0;
   



TH1F* h1 = new TH1F("h1", "Decaimiento del muon",40, 0.5, 40.0);
/*
TFile *af = new TFile("test.root","recreate");
TTree* mytree = new TTree("mytree","Prueba");
TBranch *b1 = mytree->Branch("Var_a_Branch",&count,"count/D");
TBranch *b2 = mytree->Branch("Var_b_Branch",&bins,"bins/D");
*/
while(std::getline( CVSFile, line )){

    NumericValue = true;
    lineNumber++;
    if((pos = line.find(",")) != std::string::npos) {
        time= std::stoi(line.substr(0, pos));
        time *=0.001;
        line.erase(0, pos + 1);
    }
    
    
    if(NumericValue) h1->Fill(time);

}

    fstream ReadFile("graph.csv", ios::in);
    if(!ReadFile){
        fstream CreateFile("graph.csv", ios::out);
    }
    /* Se obtienen los datos */
    Myfile.open("graph.csv",ios::app);
    
    for(int i=0; i<=40; i++){
        bins=h1->GetBinCenter(i+2);
        count= h1->GetBinContent(i+2);
        float xerror=0; 
        xerror=h1->GetBinError(i+2);
        Myfile<<bins<< ","<<count<<","<<xerror<<"\n";
        //mytree->Fill();
    }

    Myfile.close();
    

TCanvas *c1= new TCanvas();
h1->GetXaxis()->SetTitle("Tiempo");
h1->GetYaxis()->SetTitle("Conteos");

h1 ->Draw();


gStyle->SetOptFit(1);

TF1 *lFunc = new TF1("exp","expo(1)+pol0",0.5,40);
lFunc->SetParameter(500,2.2);
lFunc->SetParNames("C","A", "B");
h1->Fit(lFunc,"R");



     
}

