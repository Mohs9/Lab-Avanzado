/*
 *Código para encontrar tiempo de decimiento.
  Rubí Esmeralda Ramírez Milián.
 * 
 * Basado en el código de Hector Pérez
 *
 * 
 */

#include <string>
#include <vector>
#include <cmath>
#include <iostream>
#include <cstring>
#include <fstream>
#include <sstream>
#include <stdio.h>
#include <stdlib.h>

#include "TROOT.h"
#include "TFile.h"
#include "TTree.h"
#include "TH1.h"
#include "TCanvas.h"
using namespace std;
fstream Myfile;

/* Este programa toma como argumento el nombre del archivo .root donde se
 * encuentran los datos provenientes de Escaramujo */
int main(int argc, char *argv[]) {
  
   if( argc < 2 )
  {
    std::cout << "Error: No input file\n";
    std::exit(1);
  }

  TFile *DataFile = new TFile( argv[1] );
  TTree *dataTree = 0;

  std::cout << argv[1] << " open..\n";

  /* Se asocia un arbol para leer los datos del archivo */

  DataFile->GetObject("dataTree", dataTree);


  std::cout << "data tree found..\n";

  dataTree->SetBranchStatus("*",0);
  dataTree->SetBranchStatus("TSDate",1);
  dataTree->SetBranchStatus("TSTime",1);
  dataTree->SetBranchStatus("TSNs",1);
  dataTree->SetBranchStatus("RE0",1);
  dataTree->SetBranchStatus("FE0",1);
  dataTree->SetBranchStatus("RE1",1);
  dataTree->SetBranchStatus("FE1",1);
  dataTree->SetBranchStatus("RE2",1);
  dataTree->SetBranchStatus("FE2",1);
  dataTree->SetBranchStatus("RE3",1);
  dataTree->SetBranchStatus("FE3",1);


  std::cout << "brances activated..\n";
  
  /* Variables para cargar los datos del archivo
   *
   * TSDateData: Cadena de caracteres que aloja la fecha de captura de datos */
	char TSDateData[7];
  /* TSTimeData: Cadena de caracteres que aloja la hora de captura de datos
   * con presición de segundos */
	char TSTimeData[7];
  /* TSNsData: Entero que indica los nanosegundos transcurridos desde 
   * TSTimeData hasta el inicio del evento capturado */
	uint32_t TSNsData;

  /* RE<ch>: Vectores que contienen los tiempos en los cuales el voltaje 
   * de la señal de los pulsos excedieron el umbral predefinido para el canal ch.
   * Los tiempos son los nanosegundos que transcurrieron desde TSNsData.
   * 
   * FE<ch>: Vectores que contienen los tiempos en los cuales el voltaje
   * de la señal de los pulsos dejaron de exceder el umbral predefinido 
   * para el canal ch. Tambien están medidos en nanosegundos desde
   * TSNsData. */
  std::vector<float> *RE0 = 0;
  std::vector<float> *FE0 = 0;
  std::vector<float> *RE1 = 0;
  std::vector<float> *FE1 = 0;
  std::vector<float> *RE2 = 0;
  std::vector<float> *FE2 = 0;
  std::vector<float> *RE3 = 0;
  std::vector<float> *FE3 = 0;


  dataTree->SetBranchAddress("TSDate",TSDateData);
  dataTree->SetBranchAddress("TSTime",TSTimeData);
  dataTree->SetBranchAddress("TSNs",&TSNsData);
  dataTree->SetBranchAddress("RE0",&RE0);
  dataTree->SetBranchAddress("FE0",&FE0);  
  dataTree->SetBranchAddress("RE1",&RE1);
  dataTree->SetBranchAddress("FE1",&FE1);  
  dataTree->SetBranchAddress("RE2",&RE2);
  dataTree->SetBranchAddress("FE2",&FE2);  
  dataTree->SetBranchAddress("RE3",&RE3);
  dataTree->SetBranchAddress("FE3",&FE3);  
  
  
  std::cout << "brances asociated..\n";
      
  /* Variables para determinar las coincidencias */

  /* kllCutCoin: límite inferior de coincidencias. No se toman en 
   * cuenta pulsos cuya separación sea menor que este valor temporal
   * en nanosegundos. */
  int kllCutCoin = 2;
  /* kulCutCoin: límite superior de coincidencias. Si los pulsos
   * están separados mas de este tiempo, no se consideran coincidencias.
   * (valor en nanosegundos) */
  int kulCutCoin = 4;

/* Se debe tomar en cuenta un tercer pulso tiempo después del kulCut Coin en la tercera placa*/

 /* time_decay_inf: límite inferior de coincidencias. No se toman en 
   * cuenta pulsos cuya separación sea menor que este valor temporal
   * en nanosegundos. */
  int time_decay_inf= 1500;
  int time_decay_sup= 40000;

/*vamos a crear variables que cuenten el tiempo de decaimiento para cada evento*/
  float tiempo_mu=0;

  /* Variables para conteo de coincidencias
   *
   * El canal 0 (ch0) se asocia con la placa A
   * El canal 1 (ch1) se asocia con la placa B
   * El canal 2 (ch2) se asocia con la placa C
   * el canal 3 (ch3) no esta físicamente conectado a ninguna placa
   * 
   * La variable AnCnB_Tcounter llevan el conteo total de coincidencias */

  int AnCnB_Tcounter = 0;

  /* La variable AnCnB_counter llevan el conteo de coincidencias por evento */

  int AnCnB_counter =0;

  /* nic_counter lleva el conteo de eventos que no contienen coincidencias */
  int nic_counter = 0;
  /* La variable boleana coincidence sirve para marcar los eventos que contienen
   * coincidencias */
  bool coincidence = false;
  /*vamos a crear variables que cuenten el tiempo de decaimiento para cada evento*/


  /*Creamos un archivo csv si no existe*/
  fstream ReadFile("tiempos.csv", ios::in);
  if(!ReadFile){
    fstream CreateFile("tiempos.csv", ios::out);
    
  }

  /* Se obtiene el número de eventos en el archivo .root */
  int n_events = (int) dataTree->GetEntries();

  std::cout << n_events << " events found\n";
 
  /* Se inicia el ciclo para leer los eventos del archivo */
  for(int i=0; i<n_events; i++)
  {
    
    /* Se cargan los datos del i-ésimo evento*/
    dataTree->GetEntry(i);

    /* Iniacialización de las variables contadoras por evento */

    AnCnB_counter = 0;
  
    coincidence = false;

    /* Coincidencias entre las placas A y C (canales 0 y 2) 
     * 
     * Primero se dertemina que existan pulsos en todos los canales.
     * Para ello se verifica que el tamaño de
     * los vectores asociados a los canales 0, 1, 2 sea mayor a 0. */

    
   //Abrimos el archivo csv
   Myfile.open("tiempos.csv",ios::app);

     if((RE0->size() > 0) && (RE1->size() > 0) && (RE2->size() > 0)) // 1, 2 y 3
    {
       /* Si existen pulsos en estos canales, se mide la diferencia de 
       * tiempo en el primer pulso que llega a los canales . Luego se
       * verifica que esta diferencia de tiempo sea mayor o igual a
       * kllCutCoin y menor que kulCutCoin */

      if(( fabs(RE0->at(0)-RE2->at(0)) >= kllCutCoin ) &  ( fabs(RE0->at(0)-RE2->at(0)) <= kulCutCoin ))
      {

        /*Luego se verifica que el pulso de la primera placa y el de la tercera 
        tengan una diferencia de 1.5 a 40 micros segundos.
        */
        if(( fabs(RE0->at(0)-RE1->at(0)) >= time_decay_inf ) &  ( fabs(RE0->at(0)-RE1->at(0)) <= time_decay_sup ))
        {

        /* Si se cumple esta condición entonces se cuenta la coincidencia en A y C y la lectura en la
         * placa B */

          AnCnB_counter++;
          coincidence= true;
          /*La variable tiempo_mu almacena el valor de la diferencia entre los pulsos de la placa A y B*/

          tiempo_mu= fabs(RE1->at(0)-RE0-> at(0));
          /*Escribe el tiempo en el archivo csv.*/
          Myfile<<tiempo_mu<<","<<sqrt(tiempo_mu)<<"\n";
       
        }
         
      }
    }
    Myfile.close();


    /* Si no se encontró que se cumplieran las condiciones de coincidencia,
     * también se cuenta. */
    if(!coincidence)
    {
      nic_counter++;
    }

    /* Se actualizan los contadores totales */

    AnCnB_Tcounter += AnCnB_counter;
   }

  /* Se muestran los resultados */
  std::cout<< "Total coincidendes in channels 0,2,1: " << AnCnB_Tcounter << std::endl;
  std::cout<< "Not in coincidence: " << nic_counter << std::endl;
  std::cout<< "Not in coincidence: " << tiempo_mu << std::endl;

  DataFile->Close();

  return 0;
}

  



