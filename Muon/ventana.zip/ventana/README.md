README
Los eventos capturados que contienen una coincidencia en las placas A y C. Se busca
un pulso en la placa B un tiempo después de transcurrida la coincidencia. Para obtener el 
tiempo entre la coincidencia y el pulso en la placa B se tiene el programa ventana.cc.

PROGRAMA 1
ventana.cc : Para compilarlo se entra en la terminal

$make
$./ventana.exe  "nombre del archivo con los datos"

Este programa extrae datos y los escribe en un archivo csv llamado "tiempos.csv"

PROGRAMA 2
hist.cpp : Entrar a root para realizar el histograma y hacer el ajuste de la función exponencial al histograma 
para obtener la vida media del muón.

root[0].L hist.cpp
root[1]ReadCSV("tiempos.csv")

El programa lee el archivo csv y realiza el histograma y entrega los parámetros A, B y C de la función A*exp(-B*x)+C según el fit.
Además devuelve un archivo con los datos del histograma llamado "graph.csv"

PROGRAMA 3

decay.gnu: Programa que obtiene datos del archivo "graph.csv" y realiza también un fit en el software Gnuplot. 

$gnuplot
$load decay.gnu